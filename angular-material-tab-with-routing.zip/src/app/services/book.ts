export class Book {
   id: number;
   name: string;
   price: string;
   description: string;
   constructor() { 
   }
}